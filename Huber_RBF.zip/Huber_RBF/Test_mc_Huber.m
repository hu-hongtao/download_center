%% Test_MC
function [NMAE RMSE] = Test_mc_Huber(para)

% parameters

M = para.X;
W = para.W;
r = para.r;
size = para.size;
m = size(1);
n = size(2);
Omega = para.Omega;
data = para.data;
Test_ind = para.test.Ind;
Test_values = para.test.values;
dif = para.dif;

% test algorithms

[L] = Huber_RBF_MC(M, Omega, r,0.2, 1e-4, 500);
%% TEST
Rvec = L(Test_ind)-Test_values;
NMAE = mean(abs(Rvec))/dif;
RMSE = sqrt(mean(Rvec.*Rvec));