
clc
clear all
%% ����·��
addpath(genpath('Realdata'))
addpath(genpath('solver'))
%% ��������
Data_num = 4;

Data = load_data(Data_num);
[m,n] = size(Data);

if Data_num > 3
    Data = full(Data');
else
    Data = full(Data');
end

[m,n] = size(Data);

% Training data
SR   = 0.9;              
M_train = random_sampling(Data, SR);  
 
Omega  = find(M_train);   % 
data = M_train(Omega);   

% parameters
rank = 5;
Test_ind = find(Data - M_train);      % Test ID
para.test.Ind = Test_ind;
para.test.values = Data(Test_ind);     % Test values

para.Omega = Omega;
para.size = [m,n];
para.data = data;
para.X = M_train;
para.r = rank;

[I,J] = ind2sub([m,n],Omega); 
para.W = sparse(I,J,ones(length(Omega),1),m,n,length(Omega));

if Data_num>3
    para.dif = 4;
else
    para.dif =20;
end
[NMAE RMSE] = Test_mc_Huber(para);
Out.Huber = [NMAE RMSE];     


































