%% load Data

function Data = load_data(data_num)

addpath(genpath('Realdata'))

if data_num == 1
    load('jester-1.mat')
    Data = M;
elseif data_num == 2
    load('jester-2.mat')
    Data = M;
elseif data_num == 3
    load('jester-3.mat')
    Data = M;
elseif data_num == 4
    load('moive-100K.mat')
    Data = M;
elseif data_num == 5
    load('moive-1M.mat')
    Data = M;
elseif data_num == 6
    load('moive-10M.mat')
    Data = M;
end
