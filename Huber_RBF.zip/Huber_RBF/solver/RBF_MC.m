function [LM, errList]= RBF_MC(D, Omega, ranks, lambda, tol, maxIter)
%
% This routine solves the following robust bilinear factorizaiton (RBF) problem 
% via the Alternation Direction Method of Multipliers (ADMM), which has been  
% presented in our paper:
%
% F. Shang, Y. Liu, H. Tong, J. Cheng and H. Cheng.
% "Robust Bilateral Factorization with Missing and Grossly Corrupted
% Observations," Information Sciences, Vol. 307, pp. 53-72, 2015.
%
%------------------------------
% min |M|_* + lambda/2*||P_{Omega}(Z)-P_{Omega}(D)||^2_F
% s.t., Z = LM', L'L = I.
%      
%--------------------------------
% inputs:
%
% D      -- m*n data matrix, m is the data dimension, and n is the number
%           of data vectors.
% Omega  -- Indicator matrix of size m*n, with '1' means 'observed', and '0' 'missing'.
% ranks  -- Ranks
% lambda -- Regularization parameter
% tol    -- Tolerance for stopping criterion
% maxIter-- Maximum iteration number, usually 500. 
%
% created by Fanhua Shang on 5/25/2014, fhshang@cse.cuhk.edu.hk

[m, n] = size(D);
if nargin < 6
    maxIter = 500;  
end
if nargin < 5
    tol = 1e-4; 
end
if nargin < 4
   lambda = 1/sqrt(max(m,n));
end
if nargin < 3
    ranks = guessRank(D);
end
if nargin < 2
    disp('Please input the observation D, the indicator Omega, and try again.');
end

% Initialization
rho    = 1.03; 
max_mu = 1e10;
options.tol = 1e-8;
if max(m,n)<500
    mu = 0.2/svds(sparse(D),1,'L',options);
else
    mu = 1/svds(sparse(D),1,'L',options);
end
svp   = 1;   
rInc  = 1;
gap   = 5;
temp  = zeros(m,n);
errList = zeros(maxIter, 1);

% Initializing variables
tempd = D(Omega);
clear D
normd = norm(tempd);
Z     = zeros(m, n);
Z(Omega)= tempd;
M     = rand(n,ranks);
M(M>0.5)= 0;
Y     = zeros(m,n);
[L,P] = qr(Z*M, 0); 

% Start main loop
iter = 0;
disp(['initial,rank=' num2str(rank(Z))]);

while iter < maxIter
    
    iter = iter + 1;   
    mu1  = 1/mu;
    
     % Updata L
    temp = Z + Y*mu1; 
    [L, P] = qr(temp*M,0);     
 
    
    % Updata M
    if svp <= round(ranks/2)+1
        [U,sigma,V] = lansvd(temp'*L,svp,'L');        
    else
        [U,sigma,V] = svd(temp'*L, 'econ'); 
    end    
    sigma = diag(sigma);
    tol1  = max([m,n])*eps(max(sigma));
    svp = sum(sigma > max(tol1, mu1));
    if svp >= 1 & svp < 6
        sigma = max(sigma(1:svp)-mu1, 0);
    elseif svp >= 6
        ratio = sigma(1:end-1)./sigma(2:end);
        idxstart = 5;
        idxbig = find(abs(ratio(idxstart:end)) > gap);   
        if ~isempty(idxbig)
            svp = (idxstart-1)+idxbig(1);
        else
            svp = length(find(sigma>max(tol1, mu1))); 
        end
        sigma = max(sigma(1:svp)-mu1, 0);
    else
        svp   = 1;
        sigma = 0;
    end
    M   = U(:,1:svp)*diag(sigma(1:svp))*V(:,1:svp)';
    svp = min(svp+rInc, ranks);
    
    % Updata Z
    LM = L*M';
    Z  = LM - Y*mu1;
    Z(Omega) = (Z(Omega)*mu + tempd*lambda)/(mu+lambda);     
    
    % Stop conditon
    temp  = Z - LM;
    stopC = norm(temp(:))/normd;   
    errList(iter) = stopC;
    
    if iter==1 || mod(iter,50)==0 || stopC<tol
        disp(['iter ' num2str(iter) ', mu=' num2str(mu,'%2.1e') ...
           ', stopADMM=' num2str(stopC,'%2.3e')]);
    end 
    
    if stopC < tol
        break;        
    else             
        mu = min(max_mu, mu*rho);      
        Y  = Y + mu*temp;
    end  

end
errList = errList(1:iter);
end


% Function to Guess the Rank of the input Matrix
function r = guessRank(M_E);
	[n m] = size(M_E);
	epsilon = nnz(M_E)/sqrt(m*n);
    S0 = svds(M_E,100) ;

    S1=S0(1:end-1)-S0(2:end);
    S1_ = S1./mean(S1(end-10:end));
    r1=0;
    lam=0.05;
    while(r1<=0)
        for idx=1:length(S1_)
            cost(idx) = lam*max(S1_(idx:end)) + idx;
        end
        [v2 i2] = min(cost);
        r1 = max(i2-1);
        lam=lam+0.05;
    end

	clear cost;
    for idx=1:length(S0)-1
        cost(idx) = (S0(idx+1)+sqrt(idx*epsilon)*S0(1)/epsilon  )/S0(idx);
    end
    [v2 i2] = min(cost);
    r2 = max(i2);

	r = max([r1 r2]);
end