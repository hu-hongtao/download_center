function [LM, E, L, M] = RBF_RMC(D, Omega, lambda, rank_est, rho, tol, maxIter, DEBUG)
% 
% This routine solves the following robust bilinear factorizaiton (RBF) problem 
% via the Alternation Direction Method of Multipliers (ADMM), which has been  
% presented in our paper:
%
% F. Shang, Y. Liu, H. Tong, J. Cheng and H. Cheng.
% "Robust Bilateral Factorization with Missing and Grossly Corrupted
% Observations," Information Sciences, Vol. 307, pp. 53-72, 2015.
%
%------------------------------
% Model for Robust Principal Component Analysis (RPCA) 
% min  |M|_{*} + lambda|E|_{1},
% s.t., D = LM + E, L'L=I.
%
%------------------------------
% Model for Robust Matrix Completion (RMC)
% min  |M|_{*} + lambda|E_{W}|_{1}
% s.t., D = LM + E, L'L=I.
%
%--------------------------------
%Input: 
%   D:        Input data matrix of size m*n 
%   Omega:    Indicator matrix of size m*n, with '1' means 'observed', and '0' 'missing'.
%   lambda:   Regularization paramter
%   rank_est: Estimation rank
%   rho:      Increasing ratio of the penalty parameter mu, usually 1.05.
%   tol:      Tolerance for stopping criterion
%   maxIter:  Maximum iteration number, usually 1000.
%
%Output:
%   LM: m*n  low-rank component, such that LM = L*M.
%   E : m*n  sparse component
%   L : m*d  dictionary matrix
%   M : d*n  data reprensetaion matrix
%
% created by Fanhua Shang on 5/25/2014, fhshang@cse.cuhk.edu.hk

% Default parameters
[m, n] = size(D);

if (~exist('DEBUG','var'))
    DEBUG = 1;
end

if nargin < 7
    maxIter = 500; 
end

if nargin < 6
    tol = 1e-4; 
end

if nargin < 5
    rho = 1.05; 
end

if nargin < 4
    rank_est = round(1.2*rank_estimation(D));
end

if nargin < 3
    lambda = 1/sqrt(max(m,n));
end
if nargin < 2
    disp('Please input the observation D, the indicator Omega, and try again.');
end

if Omega == 0
    weight = 1;
else
    weight = 0;
end

% Parameter set
max_mu = 1e10;
%mu = 0.5*1e-3; 
options.tol = 1e-8;
mu = 1/svds(sparse(D),1,'L',options);

% Initializing variables
normD = norm(D, 'fro');
Y     = D / normD;
E     = sparse(m, n);
M     = rand(rank_est, n);
M(M>0.5)= 0;
temp  = zeros(m, n);

% Start main loop
iter = 0;
while iter < maxIter
    iter = iter + 1;   
    mu1  = 1/mu;
    
    % Update L
    % min |L*M+E-X-Y/mu|^{2}_F   
    temp = D - E + Y*mu1;          
    [L, S] = qr(temp * M', 0);   
    
    
    % Update M
    % min lambda*|M|_*+(mu/2)*|L*M+E-X-Y/mu|^{2}_F 
    [U,sigma,V] = svd(L'*temp, 'econ');
    %[U,sigma,V] = mexsvd(L'*temp, 0);
    sigma = diag(sigma);
    svp = length(find(sigma > mu1));
    if svp >= 1
        sigma = sigma(1:svp) - mu1;
    else
        svp   = 1;
        sigma = 0;
    end
    M = U(:,1:svp)*diag(sigma)*V(:,1:svp)';         
    LM = L*M; 
 
    
    % Update E    
    % min |W.*E|_1+(mu/2)*|E+LM-X-Y/mu|^{2}_F 
    % or min |E|_1+(mu/2)*|E+LM-X-Y/mu|^{2}_F 
    temp = D - LM + Y*mu1; 
    if weight == 1
        E = max(temp-lambda*mu1, 0) + min(temp+lambda*mu1, 0);
    else
        E = temp; 
        E(Omega) = max(0, E(Omega)-lambda*mu1) + min(0, E(Omega)+lambda*mu1);   
    end
    
    % Stopping criteria      
    temp = D - LM - E;
    stopC = norm(temp, 'fro')/normD;
    errList(iter) = stopC;
    
    if DEBUG
         if iter==1 || mod(iter,20)==0 || stopC<tol
             disp(['iter ' num2str(iter) ',mu=' num2str(mu,'%2.1e') ...
            ',recErr=' num2str(stopC,'%2.3e')]);
         end
    end 
    
    if stopC < tol         
       break;        
    else
        % Update Y
        Y = Y + temp*mu;
        mu = min(max_mu, mu*rho);
    end
    
end
errList = errList(1:iter);
end
    
    
    
% This Function to Estimate the Rank of the Input Matrix
function d = rank_estimation(X)
	
[n m] = size(X);
epsilon = nnz(X)/sqrt(m*n);
mm = min(100, min(m, n));
S0 = lansvd(X, mm, 'L');

S1 = S0(1:end-1)-S0(2:end);
S1_ = S1./mean(S1(end-10:end));
r1 = 0;
lam = 0.05;
while(r1 <= 0)
    for idx = 1:length(S1_)
        cost(idx) = lam*max(S1_(idx:end)) + idx;
    end
    [v2 i2] = min(cost);
    r1 = 2*max(i2-1);
    lam = lam+0.05;
end
clear cost;

for idx = 1:length(S0)-1
    cost(idx) = (S0(idx+1)+sqrt(idx*epsilon)*S0(1)/epsilon )/S0(idx);
end
[v2 i2] = min(cost);
r2 = 2*max(i2);

d = max([r1 r2]);
end
